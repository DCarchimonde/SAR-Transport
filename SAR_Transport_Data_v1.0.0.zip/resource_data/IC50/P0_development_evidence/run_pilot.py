"""Bounded, development-only reference-policy pilot. No global predictive training."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import json, hashlib, time, csv, gzip, collections, datetime, math
import numpy as np
import pandas as pd
from scipy.special import ndtr
from scipy.integrate import quad
from rdkit import Chem, DataStructs
from rdkit.Chem import rdFingerprintGenerator

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent/'sar_review_20261104/bundle'
REPORT=ROOT/'reports/sar_transport_v1'
TAU=.3115195915190363
LAM=.1
POLICIES=['maxmin','facility','point_vopt','contrast_vopt','pairwise_kg','source_spread','random17','random43','random71']
LEDGER=collections.Counter()
START=time.process_time()
WALL=time.monotonic()

def sha(x):return hashlib.sha256(x.encode()).hexdigest()
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def guard():
    if LEDGER['affine_fits']+LEDGER['kernel_solves']>15000:raise RuntimeError('new operation budget exceeded')
    if time.process_time()-START>3600:raise RuntimeError('new CPU budget exceeded')

def gain(m,q):
    m=np.abs(np.asarray(m));q=np.asarray(q);s=np.sqrt(np.maximum(q,0));z=m/np.maximum(s,1e-100)
    z=np.minimum(z,1e100)
    g=s*np.exp(-.5*z*z)/np.sqrt(2*np.pi)-m*ndtr(-z)
    return np.where(q>1e-20,np.maximum(g,0),0.)

def synthetic_checks():
    assert float(gain(0.,0.))==0.
    assert abs(float(gain(0.,.25))-.5/np.sqrt(2*np.pi))<1e-12
    for m,q in [(0.,.2),(.4,.3),(2.,.2)]:
        numeric=.5*(quad(lambda z:abs(m+np.sqrt(q)*z)*np.exp(-z*z/2)/np.sqrt(2*np.pi),-12,12,epsabs=1e-10)[0]-abs(m))
        assert abs(float(gain(m,q))-numeric)<1e-7
    rng=np.random.default_rng(1);X=rng.normal(size=(9,7));K=X@X.T
    K=K/np.sqrt(np.diag(K)[:,None]*np.diag(K)[None,:])
    c=[0,1,2];V=TAU**2*(K-K[:,c]@np.linalg.solve(K[np.ix_(c,c)]+LAM*np.eye(3),K[c,:]))
    a,b,z=4,5,8;q=(V[a,z]-V[b,z])**2/(V[z,z]+TAU**2*LAM)
    assert q<=V[a,a]+V[b,b]-2*V[a,b]+1e-10
    assert np.linalg.eigvalsh(V).min()>-1e-10
    return {'analytic_KG_matches_numeric_quadrature':True,'zero_and_zero_margin_cases':True,'posterior_PSD_and_q_bound':True,'synthetic_solves':1,'numeric_integrations':3}

def id_design():
    task=pd.read_csv(REPORT/'TASKS.tsv',sep='\t',dtype=str)
    task=task[(task.split=='development')&(task.status=='eligible')]
    ids=set(task.task_id)
    edges=pd.read_csv(REPORT/'ALL_ELIGIBLE_EDGES.tsv.gz',sep='\t',usecols=['task_id','compound_a','compound_b'],dtype=str)
    edges=edges[edges.task_id.isin(ids)]
    bytask={k:g for k,g in edges.groupby('task_id',sort=False)}
    chosen=[];excluded=[]
    groups=sorted(task.group_id.unique(),key=lambda x:(sha('ref_p0|'+x),x))
    for group in groups[:64]:
        row=task[task.group_id==group].sort_values('task_id').iloc[0]
        ee=bytask[row.task_id]
        mols=sorted(set(ee.compound_a)|set(ee.compound_b))
        role=sorted(mols,key=lambda x:(sha('sentinel_v0|'+x),x))
        sentinel=set(role[:len(mols)//2]);pool=sorted(set(mols)-sentinel)
        query_edges=sorted(set(tuple(sorted([a,b])) for a,b in zip(ee.compound_a,ee.compound_b) if a in sentinel and b in sentinel))
        if len(pool)<8 or not query_edges:
            excluded.append({'group_id':group,'task_id':row.task_id,'reason':'fixed task fails pool/query criteria'});continue
        deg=collections.Counter(x for e in query_edges for x in e)
        w=np.array([1/deg[a]+1/deg[b] for a,b in query_edges]);w/=w.sum()
        chosen.append({'task_id':row.task_id,'group_id':group,'source_assay':row.source_assay,'target_assay':row.target_assay,'ids':mols,'sentinel_ids':sorted(sentinel),'pool_ids':pool,'query_ids':sorted(deg),'edges':query_edges,'weights':w.tolist()})
    return chosen,excluded

def main():
    if (HERE/'PROTOCOL_FREEZE.json').exists():raise RuntimeError('Frozen run already exists; do not silently rerun')
    checks=synthetic_checks()
    designs,excluded=id_design()
    identity=pd.read_csv(REPORT/'COMPOUND_IDENTITY.tsv',sep='\t',dtype=str)
    smiles=dict(zip(identity[identity.status=='eligible'].canonical_compound_id,identity[identity.status=='eligible'].canonical_isomeric_smiles))
    required=set(x for t in designs for x in t['ids'])
    generator=rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=2048)
    fps={}
    for x in sorted(required):
        mol=Chem.MolFromSmiles(smiles[x])
        if mol is None:raise RuntimeError('structure not parseable '+x)
        fps[x]=generator.GetFingerprint(mol)
    for t in designs:
        ids=t['ids'];K=np.array([DataStructs.BulkTanimotoSimilarity(fps[x],[fps[y] for y in ids]) for x in ids])
        pool=[ids.index(x) for x in t['pool_ids']];c=[pool[0]]
        while len(c)<4:
            remaining=[j for j in pool if j not in c]
            c.append(min(remaining,key=lambda j:(-float(np.min(1-K[j,c])),ids[j])))
        t['initial4_ids']=[ids[j] for j in c]
    protocol={'name':'REFERENCE_POLICY_P0','date_utc':stamp(),'status':'frozen_before_pilot_outcome_analysis','scope':'Exploratory pilot on previously exposed IC50 development tasks; no confirmatory inference',
      'scientific_results_parent':'0b22c0af92a5b9369da987e3e850a275e56949cf','groups_selected':64,'selection':'First64 development groups ordered SHA256(ref_p0|groupID), one lowest taskID each. No replacements if failure.',
      'roles':'First floor(n/2) IDs ordered SHA256(sentinel_v0|canonicalID) are sentinels; rest candidate references. Queryedges fixed original edges within sentinels.',
      'initial4':'lowestID then structural max-min; same for every policy','additional_reference_count':4,'policies':POLICIES,
      'random_interpretation':'diverse4 plus random4, not all8random; seeds17/43/71 averaged at task metric level',
      'common_affine_lambda':1.,'kernel_lambda':LAM,'working_covariance_tau_pIC50':TAU,'working_noise_variance':TAU**2*LAM,
      'scale':'Mean and populationSD of all eligible unique development observations, computed once after freeze; not chosen based on pilot outcomes',
      'source_spread':'greedy max-min .5*(1-Tanimoto)+.5*abs(source_i-source_j)/source range in reference pool; common structural initial4',
      'facility':'maximize sum fixed query-point max Tanimoto coverage','point_vopt':'maximize mean posteriorqueryvariance reduction','contrast_vopt':'maximize degreeweighted posteriorcontrastvariance reduction',
      'KG':'sum edgeweights*(sqrt(q)*phi(abs(m)/sqrt(q))-abs(m)*Phi(-abs(m)/sqrt(q))); q=cov(delta,z|C)^2/(Vzz+tau²lambda); locally fixed affine within lookahead, actual affine refit after observingselectedreference',
      'budget':{'small_calibration_and_solve_operations':15000,'CPU_hours':1,'RAM_GiB':8,'neural_global_fits':0,'RF_global_fits':0},
      'scoring':'same frozen edges and degreeweights; one task/group means group equal; no bootstrap; all 9 policies and source reported; KG against strongest nonKG pointestimate descriptive only',
      'exposure':'No Ki data accessed. Old IC50 results alreadyexposed; initialschema inspection parsed2 previouslyexposed observationrows, no effect analysis. No oldbudget reclassification.',
      'script_sha256':digest(__file__),'input_sha256':{str(p.relative_to(ROOT)):digest(p) for p in [REPORT/'TASKS.tsv',REPORT/'ALL_ELIGIBLE_EDGES.tsv.gz',REPORT/'COMPOUND_IDENTITY.tsv',ROOT/'data/sar_transport/restricted/UNIQUE_OBSERVATIONS.tsv.gz']},
      'synthetic_checks':checks,'selected_task_ids':[t['task_id'] for t in designs],'fixed_exclusions':excluded}
    dump(HERE/'PROTOCOL.json',protocol);dump(HERE/'TASK_DESIGNS.json',designs)
    dump(HERE/'PROTOCOL_FREEZE.json',{'frozen_utc':stamp(),'protocol_sha256':digest(HERE/'PROTOCOL.json'),'task_designs_sha256':digest(HERE/'TASK_DESIGNS.json'),'script_sha256':digest(__file__)})
    # Only after freezing identities and methods, load development numerical values.
    obs={};devvalues=[]
    with gzip.open(ROOT/'data/sar_transport/restricted/UNIQUE_OBSERVATIONS.tsv.gz','rt') as f:
        for row in csv.DictReader(f,delimiter='\t'):
            if row['split']!='development':continue
            y=float(row['pchembl']);devvalues.append(y)
            obs[(row['assay_id'],row['canonical_compound_id'])]=y
    mean=float(np.mean(devvalues));sd=float(np.std(devvalues));LEDGER['development_scale_fit']=1
    dump(HERE/'DEVELOPMENT_SCALE.json',{'mean':mean,'population_sd':sd,'unique_development_observations':len(devvalues)})
    saved=[];traces=[];failures=[]
    for number,t in enumerate(designs):
        try:
            ids=t['ids'];n=len(ids);index={x:j for j,x in enumerate(ids)}
            pool=np.array([index[x] for x in t['pool_ids']],dtype=int);query=np.array([index[x] for x in t['query_ids']],dtype=int)
            ea=np.array([index[a] for a,b in t['edges']],int);eb=np.array([index[b] for a,b in t['edges']],int);w=np.array(t['weights'])
            xs=np.array([obs[(t['source_assay'],x)] for x in ids]);K=np.array([DataStructs.BulkTanimotoSimilarity(fps[x],[fps[y] for y in ids]) for x in ids])
            initial=tuple(index[x] for x in t['initial4_ids']);cache={}
            # oracle is the only selection-time target-value interface
            def oracle(c):
                assert set(c)<=set(pool) and not(set(c)&set(query))
                return np.array([obs[(t['target_assay'],ids[j])] for j in c])
            def fit(c):
                c=tuple(c)
                if c in cache:LEDGER['state_cache_hits']+=1;return cache[c]
                yc=oracle(c);xx=(xs[list(c)]-mean)/sd;yy=(yc-mean)/sd
                xc=xx-xx.mean();ycc=yy-yy.mean();b=(xc@ycc+1)/(xc@xc+1);a=yy.mean()-b*xx.mean()
                g=(a+b*(xs-mean)/sd)*sd+mean
                inverse=np.linalg.solve(K[np.ix_(c,c)]+LAM*np.eye(len(c)),np.eye(len(c)))
                pred=g+K[:,c]@inverse@(yc-g[list(c)])
                V=TAU**2*(K-K[:,c]@inverse@K[list(c),:]);V=.5*(V+V.T)
                if np.min(np.diag(V)) < -1e-8:raise RuntimeError('material negative posterior variance')
                LEDGER['affine_fits']+=1;LEDGER['kernel_solves']+=1;guard()
                cache[c]=(pred,V);return pred,V
            pred4,_=fit(initial)
            for policy in POLICIES:
                c=list(initial);trace=[]
                rng=np.random.default_rng(int(sha(t['task_id']+'|'+policy)[:16],16))
                for step in range(4):
                    remaining=np.array([j for j in pool if j not in c],dtype=int)
                    pred,V=fit(c)
                    if policy=='maxmin':score=np.min(1-K[np.ix_(remaining,c)],axis=1)
                    elif policy=='facility':
                        before=np.max(K[np.ix_(query,c)],axis=1)
                        score=np.maximum(K[np.ix_(query,remaining)]-before[:,None],0).sum(0)
                    elif policy=='source_spread':
                        spread=max(float(np.ptp(xs[pool])),1e-12)
                        d=.5*(1-K[np.ix_(remaining,c)])+.5*np.abs(xs[remaining,None]-xs[None,c])/spread
                        score=np.min(d,axis=1)
                    elif policy.startswith('random'):
                        seed=int(policy[6:]);seedrng=np.random.default_rng(int(sha(t['task_id']+'|'+str(seed))[:16],16))
                        order=seedrng.permutation([j for j in pool if j not in initial]);j=int(order[step]);score=None
                    else:
                        den=np.maximum(np.diag(V)[remaining],0)+TAU**2*LAM
                        if policy=='point_vopt':score=(V[np.ix_(query,remaining)]**2/den).mean(0)
                        else:
                            cross=V[np.ix_(ea,remaining)]-V[np.ix_(eb,remaining)]
                            q=cross**2/den
                            edge_var=np.maximum(np.diag(V)[ea]+np.diag(V)[eb]-2*V[ea,eb],0)
                            if np.any(q>edge_var[:,None]+1e-8):raise RuntimeError('KG informationvariance exceeds contrastvariance')
                            score=w@q if policy=='contrast_vopt' else w@gain((pred[ea]-pred[eb])[:,None],q)
                    if score is not None:j=int(min(range(len(remaining)),key=lambda k:(-float(score[k]),ids[int(remaining[k])])));j=int(remaining[j])
                    trace.append({'step':len(c)+1,'selected_id':ids[j],'policy_score':None if score is None else float(score[list(remaining).index(j)])})
                    c.append(j);LEDGER['policy_acquisition_steps']+=1
                pred8,_=fit(c)
                saved.append({'task_id':t['task_id'],'group_id':t['group_id'],'policy':policy,'ids':ids,'query_ids':t['query_ids'],'context8_ids':[ids[j] for j in c],'predicted':pred8[query].tolist(),'predicted4':pred4[query].tolist(),'source_prediction':xs[query].tolist()})
                traces.append({'task_id':t['task_id'],'policy':policy,'trace':trace})
            print(f'PREDICTED {number+1}/{len(designs)}',flush=True)
        except Exception as e:
            failures.append({'task_id':t['task_id'],'error':repr(e)})
            raise
    dump(HERE/'PREDICTIONS.json',saved);dump(HERE/'ACQUISITION_TRACES.json',traces)
    dump(HERE/'PREDICTIONS_FREEZE.json',{'utc':stamp(),'predictions_sha256':digest(HERE/'PREDICTIONS.json'),'traces_sha256':digest(HERE/'ACQUISITION_TRACES.json'),'query_scoring_started':False})
    # Scoring starts after all policy trajectories and predictions are frozen.
    designmap={t['task_id']:t for t in designs};metrics=[]
    for record in saved:
        t=designmap[record['task_id']];ids=record['query_ids'];ix={x:j for j,x in enumerate(ids)}
        ea=np.array([ix[a] for a,b in t['edges']]);eb=np.array([ix[b] for a,b in t['edges']]);w=np.array(t['weights'])
        y=np.array([obs[(t['target_assay'],x)] for x in ids]);source=np.array(record['source_prediction']);pred=np.array(record['predicted']);p4=np.array(record['predicted4'])
        def choose(p):
            d=p[ea]-p[eb];return np.where(np.abs(d)<=1e-8,np.array([a<b for a,b in t['edges']]),d>0)
        def losses(p):return np.maximum(y[ea],y[eb])-np.where(choose(p),y[ea],y[eb])
        ls=losses(source);lp=losses(pred);l4=losses(p4)
        rescue=np.where((ls>0)&(lp==0),ls,0);harm=np.where((ls==0)&(lp>0),lp,0)
        assert abs(float((ls-lp)@w)-float((rescue-harm)@w))<1e-9
        metrics.append({'task_id':record['task_id'],'group_id':record['group_id'],'policy':record['policy'],'L':float(lp@w),'L_at4':float(l4@w),'source_L':float(ls@w),'rescued_loss':float(rescue@w),'introduced_loss':float(harm@w),'MAE':float(np.mean(abs(pred-y))),'query_points':len(ids),'query_edges':len(w),'pool_size':len(t['pool_ids'])})
    df=pd.DataFrame(metrics);df.to_csv(HERE/'PER_TASK_METRICS.tsv',sep='\t',index=False)
    aggregate={p:{k:float(d[k].mean()) for k in ['L','L_at4','source_L','rescued_loss','introduced_loss','MAE']} for p,d in df.groupby('policy')}
    random=df[df.policy.str.startswith('random')].groupby(['task_id','group_id']).mean(numeric_only=True)
    aggregate['random_mean']={k:float(random[k].mean()) for k in ['L','L_at4','source_L','rescued_loss','introduced_loss','MAE']}
    comparators=['maxmin','facility','point_vopt','contrast_vopt','source_spread','random_mean']
    best=min(comparators,key=lambda p:aggregate[p]['L'])
    selectionmap={(r['task_id'],r['policy']):set(r['context8_ids'][4:]) for r in saved}
    overlaps={p:float(np.mean([len(selectionmap[(t['task_id'],'pairwise_kg')]&selectionmap[(t['task_id'],p)])/4 for t in designs])) for p in comparators if p!='random_mean'}
    LEDGER['synthetic_kernel_solves']=checks['synthetic_solves'];LEDGER['numeric_integrations']=3
    results={'scope':protocol['scope'],'protocol_sha256':digest(HERE/'PROTOCOL.json'),'task_count':len(designs),'group_count':len(designs),'policies':aggregate,
      'KG_vs_descriptively_best_nonKG':{'comparator':best,'difference_L':aggregate['pairwise_kg']['L']-aggregate[best]['L'],'relative_improvement':1-aggregate['pairwise_kg']['L']/aggregate[best]['L']},
      'KG_vs_maxmin':{'difference_L':aggregate['pairwise_kg']['L']-aggregate['maxmin']['L'],'relative_improvement':1-aggregate['pairwise_kg']['L']/aggregate['maxmin']['L']},
      'KG_additional4_overlap_fraction':overlaps,'fit_and_operation_ledger':dict(LEDGER),'CPU_seconds':time.process_time()-START,'wall_seconds':time.monotonic()-WALL,
      'failures':failures,'new_neural_or_RF_global_fits':0,'Ki_effects_accessed':False,'bootstrap_draws':0,'all_predictions_frozen_before_query_scoring':True,
      'interpretation':'Descriptive development pilot; KG is standard locallyfrozen Gaussian decision acquisition, not claimed new formula or calibrated guarantee. Random arms are diverse4+random4. No policy retuning after viewing results.'}
    dump(HERE/'PILOT_RESULTS.json',results)
    lines=['# Reference-policy P0: completed development pilot','',f'Frozen protocol: `{digest(HERE/"PROTOCOL.json")}`. {len(designs)} previously exposed development groups, one task per group; same fixed sentinel decisions for all policies.','', '| Policy | L at8 | Rescued loss | Introduced loss |','|---|---:|---:|---:|']
    for p,m in aggregate.items():lines.append(f'| {p} | {m["L"]:.6f} | {m["rescued_loss"]:.6f} | {m["introduced_loss"]:.6f} |')
    lines+=['',f'KG minus best nonKG ({best}): {results["KG_vs_descriptively_best_nonKG"]["difference_L"]:+.6f}. No confirmatory interval or independent confirmation is claimed.', '',f'CPU {results["CPU_seconds"]:.2f}s; ledger {dict(LEDGER)}. Old SAR budgets unchanged. No Ki values analyzed, no new global predictors.', '', 'The pilot tests reference selection only. It does not establish a new chemical law or method innovation. Acquisition uses a locally fixed affine approximation and fixed working covariance scale. All policies use structural initial4; random means random additional4.']
    (HERE/'README.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(results,indent=2))

if __name__=='__main__':main()
