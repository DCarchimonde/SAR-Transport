# Reference-policy P0: completed development pilot

Frozen protocol: `bb4008dfc7950d9d4872ec1efa4562e545081f9c7047f44625a8f8af2b78a37b`. 64 previously exposed development groups, one task per group; same fixed sentinel decisions for all policies.

| Policy | L at8 | Rescued loss | Introduced loss |
|---|---:|---:|---:|
| contrast_vopt | 0.091319 | 0.037627 | 0.020890 |
| facility | 0.091810 | 0.035197 | 0.018951 |
| maxmin | 0.088651 | 0.039333 | 0.019927 |
| pairwise_kg | 0.098045 | 0.029918 | 0.019906 |
| point_vopt | 0.092916 | 0.038545 | 0.023404 |
| random17 | 0.099551 | 0.030663 | 0.022157 |
| random43 | 0.097275 | 0.033377 | 0.022595 |
| random71 | 0.095690 | 0.030852 | 0.018486 |
| source_spread | 0.093655 | 0.038617 | 0.024215 |
| random_mean | 0.097505 | 0.031631 | 0.021079 |

KG minus best nonKG (maxmin): +0.009394. No confirmatory interval or independent confirmation is claimed.

CPU 1.52s; ledger {'development_scale_fit': 1, 'affine_fits': 1977, 'kernel_solves': 1977, 'state_cache_hits': 967, 'policy_acquisition_steps': 2304, 'synthetic_kernel_solves': 1, 'numeric_integrations': 3}. Old SAR budgets unchanged. No Ki values analyzed, no new global predictors.

The pilot tests reference selection only. It does not establish a new chemical law or method innovation. Acquisition uses a locally fixed affine approximation and fixed working covariance scale. All policies use structural initial4; random means random additional4.

## Secondary residual blend

Requested independently by the planning parent after primary execution but before this agent inspected primary results. Its separate freeze records that timing; it is not claimed to precede the primary run. Alpha grid {0,.25,.5,.75,1} is reported in full for maxmin and KG, with no new model solves. Maxmin is best at alpha1 (L=.088651); the lowest KG grid value is alpha.75 (L=.095710), still worse than maxmin. The comparison remains development-only and descriptive.

## Interpretation details

KG wins26 groups, loses26, ties12 against maxmin; its mean loss is worse by .009394 but median difference is0. There is no uncertainty interval or claim of universal policy inferiority. Unweighted point-Vopt targets mean query-point variance, while contrast-Vopt/KG use frozen edge degree weights; those comparisons combine target weighting and covariance effects. The clean KG-versus-contrastVopt comparison retains identical edgeweights and differs in its margin-aware decision score. The primary protocol was not altered after completion.
