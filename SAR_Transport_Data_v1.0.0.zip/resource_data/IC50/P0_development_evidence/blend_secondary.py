"""Secondary descriptive arithmetic only; frozen after primary run but before result inspection."""
from pathlib import Path
import json,datetime,hashlib,gzip,csv,time
import numpy as np
import pandas as pd
P=Path(__file__).resolve().parent
start=time.process_time()
amend={'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parent_protocol_sha256':hashlib.sha256((P/'PROTOCOL.json').read_bytes()).hexdigest(),'timing':'After primary pilot executed and results file existed, before agent primary-result inspection. Requested by planning parent independently of pilot effects. This is not a pre-primary-run amendment.','status':'post_execution_pre_result_inspection_secondary_descriptive_analysis','alphas':[0,.25,.5,.75,1],'policies':['maxmin','pairwise_kg'],'formula':'source + alpha*(final8_prediction-source)','no_selection_of_winning_alpha_for_confirmation':True,'new_model_fits_or_solves':0,'bootstrap_draws':0,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
af=P/'BLEND_SECONDARY_FREEZE.json'
if af.exists():raise RuntimeError('secondary already frozen')
af.write_text(json.dumps(amend,indent=2)+'\n')
pred=json.loads((P/'PREDICTIONS.json').read_text());tasks={t['task_id']:t for t in json.loads((P/'TASK_DESIGNS.json').read_text())}
obs={}
with gzip.open(P.parent/'sar_review_20261104/bundle/data/sar_transport/restricted/UNIQUE_OBSERVATIONS.tsv.gz','rt') as f:
 for r in csv.DictReader(f,delimiter='\t'):
  if r['split']=='development':obs[(r['assay_id'],r['canonical_compound_id'])]=float(r['pchembl'])
rows=[]
for r in pred:
 if r['policy'] not in amend['policies']:continue
 t=tasks[r['task_id']];ids=r['query_ids'];where={x:i for i,x in enumerate(ids)};a=np.array([where[x] for x,z in t['edges']]);b=np.array([where[z] for x,z in t['edges']]);w=np.array(t['weights']);truth=np.array([obs[(t['target_assay'],x)] for x in ids]);source=np.array(r['source_prediction']);full=np.array(r['predicted'])
 for alpha in amend['alphas']:
  pp=source+alpha*(full-source);dd=pp[a]-pp[b];choose=np.where(abs(dd)<=1e-8,np.array([x<z for x,z in t['edges']]),dd>0)
  loss=np.maximum(truth[a],truth[b])-np.where(choose,truth[a],truth[b]);rows.append({'task_id':r['task_id'],'policy':r['policy'],'alpha':alpha,'L':float(loss@w)})
df=pd.DataFrame(rows);df.to_csv(P/'BLEND_SECONDARY_PER_TASK.tsv',sep='\t',index=False)
result={'scope':amend['timing'],'means':[{'policy':p,'alpha':float(a),'L':float(g.L.mean())} for (p,a),g in df.groupby(['policy','alpha'])],'new_model_fits_or_solves':0,'cpu_seconds':time.process_time()-start}
(P/'BLEND_SECONDARY_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print('Secondary analysis finished; results not printed')
