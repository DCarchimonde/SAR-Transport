# Portable table views

These are lossless table views of the released task JSON, not new scientific analyses. `OBSERVABLE_COMPOUNDS.tsv.gz` contains source values and structures only. `REFERENCE_LABELS` contains permitted fixed-C8 target labels; acquisition pool targets live in `POOL_TRUTH` and must be accessed through BudgetOracle. `QUERY_TRUTH` is evaluator-only. `QUERY_EDGES` contains fixed, normalized edge weights. All joins require endpoint + track_id + task_id; compound IDs alone are insufficient.

`CURRENT_TASK_MANIFEST.tsv` adds current exposure status while retaining the original status at export. Historical Ki manifests were written at qualification before scoring; that time-stamped statement does not mean Ki remains unseen. All listed target outputs are now exposed. No re-splitting restores independent confirmation.
