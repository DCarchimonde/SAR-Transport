# Ki identity, structure and provenance precheck

Completed 2026-11-04. This is a source feasibility check for a future frozen reference-selection study. No Ki potency column was materialized or analyzed; no finite/conflicting-value qualification, strategy fitting, effect estimation, bootstrap or prediction was performed.

## Source and access

- Source commit: `Jnelen/ChEMBL_MatchedPairsAnalysis@0a77cdd28abf40a1562aadce727d032cd668815c`.
- Final identity projection: `Ki_MinimalCuration_Unpruned/Ki_MinimalCuration_Unpruned_Final.csv.gz`, restricted to the seven ID/target columns.
- Structure projection: the 85 same-source per-target CSV caches, restricted to assay ID, compound ID and canonical SMILES; retained only the 382 assay IDs and 2,636 compound IDs participating in the Final identity table. Raw compressed streams were not saved.
- Official ChEMBL metadata: exactly these 382 assays and their 218 associated document records. All returned; no activity endpoint was queried.
- Metadata version is ChEMBL37, release 2026-05-01; it is not the author's ChEMBL32 metadata snapshot.

## Identity/structure rules

The canonicalization algorithm matches the existing SAR script: retain stereochemistry, remove atom maps; when multiple components are present, retain a sole carbon-containing component and remove only carbon-free fragments; exclude multiple organic components; assign each normalized-structure alias group its minimum raw compound ID. Of 2,636 raw IDs, 2,585 pass and 51 have ambiguous multiple organic components. No Ki alias groups were found.

The current RDKit is 2026.09.1; prior execution used 2025.3.5. Recanonicalizing all 22,809 distinct eligible saved IC50 structures changes six canonical SMILES strings but causes no normalization failure and no change in Ki/IC50 structure overlap (166 structures both before and after). This is an explicitly recorded version check, not a claim that every future model operation is version-identical.

## Whole-group separation from IC50

Ki assays were linked by canonical compound identity, document ID and normalized DOI. Every Ki group touching any previously exposed IC50 assay, raw compound ID, eligible canonical structure, document ID or DOI was excluded whole. IC50 comparison covers all existing development/validation/evaluation source mappings, not merely the former training subset.

There are 113 Ki connected groups before exclusion; 14 touch IC50 and are removed; 99 remain. No assay has unknown provenance in the returned metadata. Numeric qualification has not yet been applied.

## Exact sentinel design

For each identity-qualified original assay pair, sort participant canonical IDs by SHA256(`sentinel_v0|` + ID), tie by ID. The first floor(n/2) IDs are fixed sentinel queries, the rest form the reference candidate pool. Retain only original analogue edges whose two endpoints are sentinels. Require n >= 20, pool >= 8 and at least one sentinel edge. No activity value enters this allocation.

After structural/identity consistency and whole-group IC50 exclusion, this gives **66 provisional tasks across 52 groups and 41 targets**, with **3,479 sentinel edges**. Minimum pool size is 10; minimum query-edge count per task is 7; the largest retained group contains three tasks. Of 41 targets, 17 were represented in IC50 and 24 were not.

The >=30-group confirmation gate is therefore plausible with explicit headroom, but it is not yet passed scientifically: finite/exact/conflict qualification may reduce coverage. These counts are not model performance, independent experiments, or proof of an independent database. Author Ki aggregate findings and CA-pruning history are already public/known. Future confirmation should be described as a frozen-policy, same-database cross-endpoint evaluation with compound/provenance separation from exposed IC50.

## Reusable outputs

`KI_PROVENANCE_SENTINEL_PRECHECK.json`, `ASSAYS.json`, `DOCUMENTS.json`, `ASSAY_SOURCE_MAPPING.tsv`, `COMPOUND_IDENTITY.tsv`, `SOURCE_ID_STRUCTURE_ONLY.tsv.gz`, `GROUPS.tsv`, `TASKS_IDENTITY_SENTINEL.tsv`, `SENTINEL_POOL_ASSIGNMENT.tsv`, `SENTINEL_EDGES.tsv.gz`, and version-check files. The adjacent script `../provenance_precheck.py` records the exact construction; `MANIFEST.json` records the outputs existing before this explanatory handoff was added.

Keep all Ki potency outcomes inaccessible to strategy development until the new acquisition rule, comparators, numeric qualification procedure and evaluation rules are frozen. This precheck does not authorize a strategy trial or expose any Ki potency outcome.
